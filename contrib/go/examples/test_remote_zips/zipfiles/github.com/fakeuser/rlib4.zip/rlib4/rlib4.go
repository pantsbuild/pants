package rlib4

import (
  "fmt"
)

func Speak() {
  fmt.Println("Hello from rlib4!")
  fmt.Println("Bye from rlib4!")
}